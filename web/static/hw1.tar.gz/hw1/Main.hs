module Main where

import qualified Hw1 as H

main :: IO ()
main = do H.sierpinskiCarpet
          H.myFractal
          H.mainXML